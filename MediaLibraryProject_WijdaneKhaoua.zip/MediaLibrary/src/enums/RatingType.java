/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enums;


public enum RatingType {
    DISLIKE(1),
    LIKE(2),
    LOVE(3);

    private final int value;

    RatingType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
