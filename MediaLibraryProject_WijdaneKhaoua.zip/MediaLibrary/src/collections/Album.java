/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package collections;

import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import medialibrary.enduser.User;
import medias.Audio;


public class Album implements Serializable {
    private String title;
   // private Date dateCreated;
    private User creator;
    private List<Audio> Audiofiles;

    public Album(String title, User creator, List<Audio> Audiofiles) {
        this.title = title;
       // this.dateCreated = new Date();
        this.creator = creator;
        this.Audiofiles = Audiofiles;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the creator
     */
    public User getCreator() {
        return creator;
    }

    /**
     * @param creator the creator to set
     */
    public void setCreator(User creator) {
        this.creator = creator;
    }

    /**
     * @return the Audiofiles
     */
    public List<Audio> getAudiofiles() {
        return Audiofiles;
    }
    
    
   
    
     public void addaudiofile(Audio AudioFile) {
        Audiofiles.add(AudioFile);
    }
     
     
     public int searchbytitle(String title) {
        Iterator<Audio> iterator = Audiofiles.iterator();
        int index = 0;

        while (iterator.hasNext()) {
            Audio audio = iterator.next();
            if (audio.getTitle().equals(title)) {
                return index;
            }
            index++;
        }
        return -1;
    }
     
     public void delete (int index){
     Audiofiles.remove(index);
     }
     
      public void reorder() {
        // Use Collections.sort without specifying a comparator, as Media now implements Comparable
        Collections.sort(Audiofiles);
    }
}

