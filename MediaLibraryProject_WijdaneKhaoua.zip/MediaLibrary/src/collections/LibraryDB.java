
package collections;


import associations.*;
import exceptions.MediaNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import medialibrary.enduser.User;
import medias.Media;


public class LibraryDB implements Serializable {

    
  public static List<Media> medias = new ArrayList<>() ;
   public static List<User> users  = new ArrayList<>();
  public static  List<Playlist> playlists = new ArrayList<>();
  public static List<Album> albums = new ArrayList<>();
   public static List<Comment> comments = new ArrayList<>();
   public  static List<Rating> ratings = new ArrayList<>();
   public static List<Follow> follows = new ArrayList<>();

    public LibraryDB() {
    }

   public static void addMedia(Media media) {
        medias.add(media);
    }

    public static void addUser(User user) {
        users.add(user);
    }

    public static void addPlaylist(Playlist playlist) {
        playlists.add(playlist);
    }

    public static void addAlbum(Album album) {
        albums.add(album);
    }
/**
     * @return the follows
     */
    public static List<Follow> getFollows() {
        return follows;
    }

    /**
     * @param aFollows the follows to set
     */
    public static void setfollows(List<Follow> aFollows) {
        follows = aFollows;
    }
    public static void addComment(Comment comment) {
        comments.add(comment);
    }

    public static void addRating(Rating rating) {
        ratings.add(rating);
    }

    public static void addFollow(Follow follow) {
        getFollows().add(follow);
    }

    // Remove functions

    public static void removeMedia(Media media) {
        medias.remove(media);
    }

    public static void removeUser(User user) {
        users.remove(user);
    }

    public static void removePlaylist(Playlist playlist) {
        playlists.remove(playlist);
    }

    public static void removeAlbum(Album album) {
        albums.remove(album);
    }

    public static void removeComment(Comment comment) {
        comments.remove(comment);
    }

    public static void removeRating(Rating rating) {
        ratings.remove(rating);
    }

    public static void removeFollow(Follow follow) {
        getFollows().remove(follow);
    }
   
  
  public static int searchmediasByName(String name) throws MediaNotFoundException {
        for (int i = 0; i < medias.size(); i++) {
            if (medias.get(i).getTitle().equals(name)) {
                return i; // Return the index when the media is found
            }
        }
        throw new MediaNotFoundException("Media not found: " + name);
    }
    
    
}
