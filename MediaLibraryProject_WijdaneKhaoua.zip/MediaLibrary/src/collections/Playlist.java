
package collections;


import exceptions.MediaNotFoundException;
import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import medias.Media;

public class Playlist implements Serializable {
    

    
    private String title;
    //private Date dateCreated;
    private List<Media> mediaFiles;

    public Playlist(String title,List<Media> mediaFiles ) {
        
        this.title = title;
       // this.dateCreated = new Date();
        this.mediaFiles = mediaFiles;
    }

    

    public String getTitle() {
        return title;
    }

    

    public List<Media> getMediaFiles() {
        return mediaFiles;
    }

    public void addMediaFile(Media mediaFile) {
        mediaFiles.add(mediaFile);
    }
    
    public boolean contains (Media media){
    
        return mediaFiles.contains(media);
    }

    public void removeMediaFile(Media mediaFile) {
       Iterator<Media> iterator = mediaFiles.iterator();
         
          while (iterator.hasNext()) {
            Media mediafile = iterator.next();

            if (mediafile.getTitle().equals(title)) {
                iterator.remove();
                
            }
        }
    }
    
    

    public Media searchByName(String name) throws MediaNotFoundException {
        for (Media media : mediaFiles) {
            if (media.getTitle().equals(name)) {
                return media;
            }
        }
        throw new MediaNotFoundException("Media not found: " + name);
    }
    
    
     public int searchByTitle(String title)  {
        Iterator<Media> iterator = mediaFiles.iterator();
        int index = 0;

        while (iterator.hasNext()) {
            Media media = iterator.next();
            if (media.getTitle().equals(title)) {
                return index;
            }
            index++;
        }
        return -1;
    }
     
     
     public void delete (int index){
     mediaFiles.remove(index);
     }
 public void reorder() {
        Collections.sort(mediaFiles);
    }
     
}
