
package medialibrary.enduser;

import collections.Album;
import collections.Playlist;
import java.io.Serializable;
import java.util.List;
import medias.Media;


public class staff extends User implements Serializable{
    private String role;
    private List<String> access; 
   // private List<comments> comments;

    public staff(String role,  String username, String email, String password, String name, List<Media> mymedias, List<Playlist> myplaylists, List<Album> myalbums) {
        super(username, email, password, name, mymedias, myplaylists, myalbums);
        this.role = role;
       // this.access = access;
    }
    
    
    
    public void setname (String name){
        setName(name);
    }

    /**
     * @param role the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * @param access the access to set
     */
    public void setAccess(List<String> access) {
        this.access = access;
    }
    
}
