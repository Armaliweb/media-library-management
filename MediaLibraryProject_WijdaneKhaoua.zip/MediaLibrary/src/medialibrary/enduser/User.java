
package medialibrary.enduser;

import collections.Album;
import collections.Playlist;
import java.io.Serializable;
import java.util.List;
import medias.Media;


public class User implements Serializable{
    
  private String username;
  private String email;
  private String password;
  private String name;
  private List<Media> mymedias;
  private List<Playlist> myplaylists;
   private List<Album> myAlbums;
  //private List<Comment> comments;
  
     public User(String username, String email, String password, String name,List<Media> mymedias,List<Playlist> myplaylists , List<Album> myAlbums )
 
{
    this.username = username;
    this.email = email;
    this.password = password;
    this.name = name;
    this.myplaylists = myplaylists;
    this.mymedias = mymedias;
    this.myAlbums = myAlbums;
    //this.comments = new ArrayList<>();
  }

  public String getUsername()
 
{
    return username;
  }

  public String getEmail()
 
{
    return email;
  }

  public String getname()
 
{
    return name;
  }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }
    
    
    
    public void addmedia(Media media){
        getMymedias().add(media);
    }

    public void addplaylist(Playlist playlist){
        myplaylists.add(playlist);
    } 

    public void addinplaylist(Playlist playlist, Media media){
  
       if (myplaylists.contains(playlist)) {
            // If the playlist is found, add the media to it
            playlist.addMediaFile(media);
            System.out.println("Media added to the playlist: " + media.toString());
        } else {
            System.out.println("Playlist not found in the user's list");
        }
  
  }

    /**
     * @return the mymedias
     */
    public List<Media> getMymedias() {
        return mymedias;
    }
      public void addAlbum(Album album){
      myAlbums.add(album)
;      }
      
      public List<Album> getmyalbums(){
      
      return myAlbums;
      }
      
      public List<Playlist> getMyPlaylists(){
          return myplaylists;
      }
  
}
    

