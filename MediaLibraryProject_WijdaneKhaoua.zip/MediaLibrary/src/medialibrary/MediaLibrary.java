/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package medialibrary;

import associations.Comment;
import associations.Follow;
import associations.Rating;
import collections.Album;
import collections.LibraryDB;
import collections.Playlist;
import exceptions.MediaNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import medialibrary.enduser.User;
import medialibrary.enduser.staff;
import medias.Audio;
import medias.Document;
import medias.Image;
import medias.Media;
import medias.Video;

public class MediaLibrary {

    static Scanner scanner = new Scanner(System.in);
    static String trash;

    public static LibraryDB DB = new LibraryDB();

    public static void main(String[] args) {
        loadData();
        homemenu();
        saveData();
    }

    private static void saveData() {
        SerializationManager.saveData(DB);
    }

    private static void loadData() {
        Object loadedData = SerializationManager.loadData();
        if (loadedData != null && loadedData instanceof LibraryDB) {
            DB = (LibraryDB) loadedData;
            System.out.println("Data loaded successfully.");
        }
    }

    public static void homemenu() {

        loop:
        while (true) {
            System.out.println("Welcome to library management \n do you want to: (1)Login \t (2)create account \n (3) add staff \t(4)quit ");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            switch (choice) {
                case 1:
                    if (LibraryDB.users.isEmpty()) {
                        System.out.println("There is no account");
                    } else {
                        login();
                    }
                    break;
                case 2:
                    signin();
                    break;
                case 3:
                    addstaff();
                    break;

                case 4:
                    break loop;

                default:
                    System.err.println("not a valid number choice");
                    break;
            }

        }

    }

    public static void login() {
        System.out.println("Please enter your email:");
        String enteredEmail = scanner.nextLine();
        System.out.println("Please enter your password:");
        String enteredPassword = scanner.nextLine();

        for (User user : LibraryDB.users) {
            if (user.getEmail().equals(enteredEmail) && user.getPassword().equals(enteredPassword)) {
                // User found, correct password
                Usermenu(user);
                return;
            } else if (user.getEmail().equals(enteredEmail)) {
                // User found, but wrong password
                System.out.println("Wrong password. Please try again.");

                break;
            }
        }

        // No user found with the entered email
        System.out.println("No user found with the provided email.");
    }

    public static void addstaff() {

        System.out.print("Please choose an email: ");
        String email = scanner.nextLine();

        System.out.print("Please provide a password: ");
        String pass = scanner.nextLine();
        System.out.print("Please choose your name: ");
        String name = scanner.nextLine();
        System.out.print("Please choose a display name: ");
        String uname = scanner.nextLine();
        System.out.print("Please choose a role: ");
        String role = scanner.nextLine();
        User u = new staff(role, uname, email, pass, name, new ArrayList<Media>(), new ArrayList<Playlist>(), new ArrayList<Album>());
        LibraryDB.users.add(u);

        System.out.print("User added succesfully");
        Usermenu(u);
    }

    public static void signin() {

        System.out.print("Please choose an email: ");
        String email = scanner.nextLine();

        System.out.print("Please provide a password: ");
        String pass = scanner.nextLine();
        System.out.print("Please choose your name: ");
        String name = scanner.nextLine();
        System.out.print("Please choose a display name: ");
        String uname = scanner.nextLine();
        User u = new User(uname, email, pass, name, new ArrayList<Media>(), new ArrayList<Playlist>(), new ArrayList<Album>());
        LibraryDB.users.add(u);

        System.out.print("User added succesfully");
        Usermenu(u);

    }

    public static void Usermenu(User User_log) {

        loop:
        while (true) {
            System.out.println("Welcome " + User_log.getname() + " \n do you want to: (1)create \t (2)read \n (3)quit ");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            switch (choice) {
                case 1:
                    creationmenu(User_log);
                    break;
                case 2:
                    readmenu(User_log);
                    break;

                case 3:
                    break loop;

                default:
                    System.err.println("not a valid number choice");
                    break;
            }

        }

    }

    public static void creationmenu(User user_log) {

        loop:
        while (true) {
            System.out.println("do you want to create: (1)media \t (2)playlist \n (3) album \t(4)quit ");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            switch (choice) {
                case 1 ->
                    createmedia(user_log);
                case 2 ->
                    createplaylist(user_log);
                case 3 ->
                    createalbum(user_log);

                case 4 -> {
                    break loop;
                }

                default ->
                    System.err.println("not a valid number choice");
            }

        }
    }

    public static void createmedia(User user_log) {

        loop:
        while (true) {
            System.out.println("the media is a: (1)Audio \t (2)Document \t (3)Image  \t (4)Video \n(5)quit ");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            System.out.print("Please enter the title: ");
            String title = scanner.nextLine();
            System.out.print("Please enter the path: ");
            String path = scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Please enter the artist: ");
                    String artist = scanner.nextLine();
                    System.out.print("Please enter the runtime: ");
                    int runtime = scanner.nextInt();
                    trash = scanner.nextLine();

                    Media a = new Audio(title, path, user_log.getUsername(), runtime, artist);

                    LibraryDB.medias.add(a);
                    user_log.addmedia(a);

                    System.out.print(a.getTitle() + "succesfully added ");
                    break;
                case 2:
                    System.out.print("Please enter the content: ");
                    String content = scanner.nextLine();
                    Media d = new Document(title, path, user_log.getUsername(), content);

                    LibraryDB.medias.add(d);
                    user_log.addmedia(d);

                    System.out.print(d.getTitle() + "succesfully added ");
                    break;
                case 3:

                    System.out.print("Please enter the location: ");
                    String location = scanner.nextLine();
                    Media i = new Image(title, path, location, user_log.getUsername());
                    LibraryDB.medias.add(i);
                    user_log.addmedia(i);

                    System.out.print(i.getTitle() + "succesfully added ");
                    break;
                case 4:
                    System.out.print("Please enter the producer name: ");
                    String producer = scanner.nextLine();
                    System.out.print("Please enter the runtime: ");
                    int runtime1 = scanner.nextInt();
                    trash = scanner.nextLine();

                    Media v = new Video(title, path, producer, runtime1);
                    LibraryDB.medias.add(v);
                    user_log.addmedia(v);

                    System.out.print(v.getTitle() + "succesfully added ");
                    break;

                case 5:
                    break loop;

                default:
                    System.err.println("not a valid number choice");
                    break;
            }

        }
    }

    public static Audio createaudio(User user_log) {

        System.out.print("Please enter the title: ");
        String title = scanner.nextLine();
        System.out.print("Please enter the path: ");
        String path = scanner.nextLine();
        System.out.print("Please enter the artist: ");
        String artist = scanner.nextLine();
        System.out.print("Please enter the runtime: ");
        int runtime = scanner.nextInt();
        trash = scanner.nextLine();

        Audio a = new Audio(title, path, user_log.getUsername(), runtime, artist);
        return a;
    }

    public static void createalbum(User user_log) {
        System.out.print("Please enter the title: ");
        String title = scanner.nextLine();
        List<Audio> audios = new ArrayList<>();

        Album album = new Album(title, user_log, audios);
        System.out.print("create and add first audio: ");

        album.addaudiofile(createaudio(user_log));

        loop:
        while (true) {
            System.out.println("do you want to add other audio: (1)yes \t(2) no, quit ");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            switch (choice) {
                case 1 ->
                    album.addaudiofile(createaudio(user_log));
                case 2 -> {
                    break loop;
                }
                default ->
                    System.err.println("not a valid number choice");
            }

        }
        if (!album.getAudiofiles().isEmpty()) {
            LibraryDB.addAlbum(album);
            user_log.addAlbum(album);
            System.out.println("Album added succesfully ");

        } else {
            System.out.println("Album was empty, not saved ");
        }
    }

    public static void readmenu(User user_log) {

        loop:
        while (true) {
            System.out.println("do you want to show: (1)all medias \t (2)your medias (modify) \t (3)all albums \n (4) your albums (modify) \t (5) your playlists (modify)\n (6)all users \t (7) your followings \t (8) quit");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            switch (choice) {
                case 1:

                    int choice1 = allmediasview();

                    if (choice1 == 0) {
                        System.out.println("exiting");
                        break;
                    } else if (choice1 > LibraryDB.medias.size()) {

                        System.out.println("invalid imput number, exiting");
                        break;
                    } else {

                        interactwitmedia(LibraryDB.medias.get(choice1 - 1), user_log);

                    }

                case 2:

                    System.out.println("here is the list of medias");
                    for (int i = 0; i < user_log.getMymedias().size(); i++) {
                        System.out.println("(" + i + 1 + ") " + user_log.getMymedias().get(i).toString());
                    }
                    System.out.println("press (0) to exit or enter the index of the media to choose ");
                    int choice2 = scanner.nextInt();
                    trash = scanner.nextLine();

                    if (choice2 == 0) {
                        System.out.println("exiting");
                        break;
                    } else if (choice2 > user_log.getMymedias().size()) {

                        System.out.println("invalid imput number, exiting");
                        break;
                    } else {

                        modifymediamenu(choice2 - 1, user_log);
                    }

                    break;
                case 3:
                    System.out.println("here is the list of albums");
                    for (int i = 0; i < LibraryDB.albums.size(); i++) {
                        System.out.println("(" + i + 1 + ") " + LibraryDB.albums.get(i).toString());
                    }
                    System.out.println("press (0) to exit or enter the index of the media to choose ");
                    int choice3 = scanner.nextInt();
                    trash = scanner.nextLine();

                    if (choice3 == 0) {
                        System.out.println("exiting");
                        break;
                    } else if (choice3 > user_log.getMymedias().size()) {

                        System.out.println("invalid imput number, exiting");
                        break;
                    } else {

                        loop1:
                        while (true) {
                            int choice4 = showalbumcontent(LibraryDB.albums.get(choice3 - 1));

                            if (choice4 == 0) {
                                break loop1;
                            } else if (choice4 == -1) {
                                System.out.println("invalid imput number");

                            } else {
                                interactwitmedia(LibraryDB.albums.get(choice3 - 1).getAudiofiles().get(choice4), user_log);
                            }

                        }

                    }
                    break;
                case 4:

                    showallmyalbums(user_log);

                    break;
                case 5:
                    showAllMyPlaylists(user_log);
                    break;
                case 6:
                    addfollow(user_log);
                    break;
                case 7:
                    showallmyfollows(user_log);
                    break;

                case 8:
                    break loop;

                default:
                    System.err.println("not a valid number choice");
                    break;
            }

        }

    }

    public static void interactwitmedia(Media media, User user_log) {
        // Media media = LibraryDB.medias.get(index);

        loop:
        while (true) {
            System.out.println("what do you want to do with" + media.getTitle() + "? (1)see details (2)rate it, (3) comment ,(4) back");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println(media.toString());
                    break;
                case 2:
                    Ratemenu(user_log, media);
                    break;

                case 3:
                    comment(user_log);
                    break;
                case 4:
                    break loop;

                default:
                    System.err.println("not a valid number choice");
                    break;
            }

        }

    }

    public static void comment(User user_log) {
        int choice = allmediasview();
        if (choice == 0) {
            System.out.println("exiting");
            return;
        } else if (choice > LibraryDB.medias.size() || choice < 0) {

            System.out.println("invalid imput number");
            comment(user_log);
        } else {

            System.out.println("imput the comment:");
            String content = scanner.nextLine();

            Comment c = new Comment(content, LibraryDB.medias.get(choice), user_log);

            LibraryDB.comments.add(c);
            System.out.println("saved");
        }

    }

    public static <T> void Ratemenu(User user_log, T content) {

        loop:
        while (true) {
            System.out.println("what do want to rate? (1)Dislike (2)Like, (3) Love, (4) cancel");
            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            if (choice == 4) {
                break loop;
            } else if (choice == 1 || choice == 2 || choice == 3) {

                Rating<T> rating = new Rating<>(user_log, choice, content);
                LibraryDB.ratings.add(rating);
                break loop;

            } else {

                System.out.println("invalid imput choice, try again");
            }

        }
    }

    public static void createplaylist(User user_log) {

        System.out.print("Please enter the title of playlist: ");
        String title = scanner.nextLine();
        List<Media> medias = new ArrayList<>();

        Playlist playlist = new Playlist(title, medias);
        //user_log.addplaylist(playlist);

        loop:
        while (true) {
            System.out.println("add a media:");

            int choice = allmediasview();

            if (choice == 0) {
                if (playlist.getMediaFiles().isEmpty()) {
                    System.out.println("playlist empty, not saved");
                } else {
                    LibraryDB.addPlaylist(playlist);
                    user_log.addplaylist(playlist);
                    System.out.println("playlist saved");
                }
                break loop;
            } else if (choice > LibraryDB.medias.size() || choice < 0) {

                System.out.println("invalid imput number");

            } else {
                int index = choice - 1;
                if (playlist.contains(LibraryDB.medias.get(index))) {
                    System.out.println("media not saved, already exists");
                } else {

                    playlist.addMediaFile(LibraryDB.medias.get(index));
                    // user_log.addinplaylist(playlist, LibraryDB.medias.get(index));
                    System.out.print(LibraryDB.medias.get(index) + " added succesfully to " + playlist.getTitle());
                }
            }

        }

    }

    public static int allmediasview() {

        loop:
        while (true) {
            System.out.println("to add do you want (1)choose from list of media, (2) search");

            int choice = scanner.nextInt();
            trash = scanner.nextLine();

            if (choice == 1) {

                System.out.println("here is the list of medias");
                for (int i = 0; i < LibraryDB.medias.size(); i++) {
                    System.out.println("(" + i + 1 + ") " + LibraryDB.medias.get(i).toString());
                }
                System.out.println("press (0) to exit or enter the index of the media to choose ");
                int choice1 = scanner.nextInt();
                trash = scanner.nextLine();
                return choice1;

            } else if (choice == 2) {
                System.out.println("enter title of the media");

                String title = scanner.nextLine();

                try {
                    return LibraryDB.searchmediasByName(title);

                } catch (MediaNotFoundException e) {
                    System.out.println(e.getMessage() + ",exiting");
                    return 0;
                }

            } else {

                System.out.println("non valid choice");
            }

        }

    }

    public static void modifymediamenu(int index, User user_log) {
        if (index < 0 || index >= LibraryDB.medias.size()) {
            System.out.println("Invalid media index.");
            return;
        }

        Media media = LibraryDB.medias.get(index);
        System.out.println("Modifying media: " + media.getTitle());

        while (true) {
            System.out.println("Choose attribute to modify: ");
            System.out.println("1. Title");
            System.out.println("2. Filepath");

            // Check the type of media and add options accordingly
            if (media instanceof Audio) {
                System.out.println("3. Artist");
                System.out.println("4. Runtime");
            } else if (media instanceof Document) {
                System.out.println("3. Creator");
                System.out.println("4. Content");
            } else if (media instanceof Image) {
                System.out.println("3. Location");
                System.out.println("4. Photographer");
            } else if (media instanceof Video) {
                System.out.println("3. Producer");
                System.out.println("4. Duration");
            }

            System.out.println("0. Quit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter new title: ");
                    String newTitle = scanner.nextLine();
                    media.setTitle(newTitle);
                    break;

                case 2:
                    System.out.print("Enter new filepath: ");
                    String newFilePath = scanner.nextLine();
                    media.setFilepath(newFilePath);
                    break;

                // Add cases for other attributes based on the media type
                case 3:
                    if (media instanceof Audio) {
                        System.out.print("Enter new artist: ");
                        String newArtist = scanner.nextLine();
                        ((Audio) media).setArtist(newArtist);
                    } else if (media instanceof Document) {
                        System.out.print("Enter new creator: ");
                        String newCreator = scanner.nextLine();
                        ((Document) media).setCreator(newCreator);
                    } else if (media instanceof Image) {
                        System.out.print("Enter new location: ");
                        String newLocation = scanner.nextLine();
                        ((Image) media).setLocation(newLocation);
                    } else if (media instanceof Video) {
                        System.out.print("Enter new producer: ");
                        String newProducer = scanner.nextLine();
                        ((Video) media).setProducer(newProducer);
                    }
                    break;

                case 4:
                    if (media instanceof Audio) {
                        System.out.print("Enter new runtime: ");
                        int newRuntime = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character
                        ((Audio) media).setRuntime(newRuntime);
                    } else if (media instanceof Document) {
                        System.out.print("Enter new content: ");
                        String newContent = scanner.nextLine();
                        ((Document) media).setContent(newContent);
                    } else if (media instanceof Image) {
                        System.out.print("Enter new photographer: ");
                        String newPhotographer = scanner.nextLine();
                        ((Image) media).setPhotographer(newPhotographer);
                    } else if (media instanceof Video) {
                        System.out.print("Enter new duration: ");
                        int newDuration = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character
                        ((Video) media).setDuration(newDuration);
                    }
                    break;

                case 0:
                    // Quit the modification menu
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static int showalbumcontent(Album album) {

        System.out.println("here is the list of medias in album");
        for (int i = 0; i < album.getAudiofiles().size(); i++) {
            System.out.println("(" + i + 1 + ") " + album.getAudiofiles().get(i).toString());
        }
        System.out.println("press (0) to exit or enter the index of the media to choose ");

        int choice = scanner.nextInt();
        scanner.nextLine();
        if (choice == 0) {
            return 0;
        } else if (choice > album.getAudiofiles().size()) {
            return -1;
        } else {
            return choice - 1;
        }

    }

    private static void showallmyalbums(User user_log) {
        List<Album> userAlbums = user_log.getmyalbums();

        if (userAlbums.isEmpty()) {
            System.out.println("You don't have any albums yet.");
        } else {
            System.out.println("Here is the list of your albums:");
            for (int i = 0; i < userAlbums.size(); i++) {
                System.out.println("(" + (i + 1) + ") " + userAlbums.get(i).getTitle());
            }

            System.out.println("Press (0) to go back or enter the index of the album to choose:");

            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 0) {
                // User chose to go back
                return;
            } else if (choice > userAlbums.size() || choice < 0) {
                // Invalid choice
                System.out.println("Invalid choice. Please enter a valid index.");
                showallmyalbums(user_log);
            } else {

                int albumIndex = choice - 1;
                ModifyAlbumMenu(user_log, albumIndex);
            }
        }
    }

    private static void ModifyAlbumMenu(User user_log, int albumIndex) {
        Album album = user_log.getmyalbums().get(albumIndex);

        while (true) {
            System.out.println("Modify Album Menu for '" + album.getTitle() + "':");
            System.out.println("1. Delete item");
            System.out.println("2. Reorder album");
            System.out.println("3. Add item");
            System.out.println("4. Back");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    deleteItemFromAlbum(album);
                    break;
                case 2:
                    reorderAlbum(album);
                    break;
                case 3:
                    addItemToAlbum(album, user_log);
                    break;
                case 4:
                    return; // User chose to go back
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void reorderAlbum(Album album) {

        album.reorder();
        System.out.println("Album reordered");
    }

    private static void addItemToAlbum(Album album, User user_log) {

        album.addaudiofile(createaudio(user_log));
    }

    private static void deleteItemFromAlbum(Album album) {
        System.out.println("Enter the title of the media to delete:");
        String titleToDelete = scanner.nextLine();

        // Call album.searchbytitle to get the index of the media with the specified title
        int indexToDelete = album.searchbytitle(titleToDelete);

        if (indexToDelete != -1) {
            // If the media is found, delete it from the album
            album.delete(indexToDelete);
            System.out.println("Media '" + titleToDelete + "' deleted from the album.");
        } else {
            System.out.println("Media '" + titleToDelete + "' not found in the album.");
        }

    }

    private static void showAllMyPlaylists(User user_log) {
        List<Playlist> userPlaylists = user_log.getMyPlaylists();

        if (userPlaylists.isEmpty()) {
            System.out.println("You don't have any playlists yet.");
        } else {
            System.out.println("Here is the list of your playlists:");
            for (int i = 0; i < userPlaylists.size(); i++) {
                System.out.println("(" + (i + 1) + ") " + userPlaylists.get(i).getTitle());
            }

            System.out.println("Press (0) to go back or enter the index of the playlist to choose:");

            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 0) {
                // User chose to go back
                return;
            } else if (choice > userPlaylists.size() || choice < 0) {
                // Invalid choice
                System.out.println("Invalid choice. Please enter a valid index.");
                showAllMyPlaylists(user_log);
            } else {
                int playlistIndex = choice - 1;
                modifyPlaylistMenu(user_log, playlistIndex);
            }
        }
    }

    public static void modifyPlaylistMenu(User user, int playlistIndex) {
        List<Playlist> myplaylists = user.getMyPlaylists();

        if (playlistIndex < 0 || playlistIndex >= myplaylists.size()) {
            System.out.println("Invalid playlist index.");
            return;
        }

        Playlist playlist = myplaylists.get(playlistIndex);

        while (true) {
            System.out.println("Modify Playlist Menu for '" + playlist.getTitle() + "':");
            System.out.println("1. Delete item");
            System.out.println("2. Reorder playlist");
            System.out.println("3. Add item");
            System.out.println("4. Back");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    deleteItemFromPlaylist(playlist);
                    break;
                case 2:
                    reorderPlaylist(playlist);
                    break;
                case 3:
                    addItemToPlaylist(playlist);
                    break;
                case 4:
                    return; // User chose to go back
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void addItemToPlaylist(Playlist playlist) {

        loop:
        while (true) {
            System.out.println("add a media:");

            int choice = allmediasview();

            if (choice == 0) {
                if (playlist.getMediaFiles().isEmpty()) {
                    System.out.println("playlist empty, not saved");
                } else {

                    System.out.println("playlist not saved");
                }
                break loop;
            } else if (choice > LibraryDB.medias.size() || choice < 0) {

                System.out.println("invalid imput number, exiting");

            } else {
                int index = choice - 1;
                if (playlist.contains(LibraryDB.medias.get(index))) {
                    System.out.println("media not saved, already exists");
                } else {

                    playlist.addMediaFile(LibraryDB.medias.get(index));

                    System.out.print(LibraryDB.medias.get(index) + " added succesfully to " + playlist.getTitle());
                }
            }

        }

    }

    private static void reorderPlaylist(Playlist playlist) {
        playlist.reorder();
        System.out.println("Album reordered");
    }

    private static void deleteItemFromPlaylist(Playlist playlist) {
        System.out.println("Enter the title of the media to delete:");
        String titleToDelete = scanner.nextLine();

        int indexToDelete = playlist.searchByTitle(titleToDelete);

        if (indexToDelete != -1) {
            playlist.delete(indexToDelete);
            System.out.println("Media '" + titleToDelete + "' deleted from the playlist.");
        } else {
            System.out.println("Media '" + titleToDelete + "' not found in the playlist.");
        }
    }

    public static void showallmyfollows(User user_log) {
        List<Follow> follows = LibraryDB.getFollows();

        if (follows.isEmpty()) {
            System.out.println("You are not following anyone yet.");
        } else {
            System.out.println("Here is the list of people you are following:");
            int index = 1;
            for (Follow follow : follows) {
                if (follow.getFollower().equals(user_log)) {
                    System.out.println("(" + index + ") " + follow.getFollowed().getUsername());
                    index++;
                }
            }

            System.out.println("Press (0) to go back or enter the index of the user to remove:");

            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 0) {
                // User chose to go back
                return;
            } else if (choice > index || choice < 0) {
                // Invalid choice
                System.out.println("Invalid choice. Please enter a valid index.");
                showallmyfollows(user_log);
            } else {
                LibraryDB.follows.remove(follows.get(choice - 1));

            }
        }
    }

    public static void addfollow(User user_log) {
        List<User> allUsers = LibraryDB.users;
        List<Follow> follows = LibraryDB.follows;

        if (allUsers.isEmpty()) {
            System.out.println("No users available to follow.");
            return;
        }

        System.out.println("Here is the list of all users:");

        for (int i = 0; i < allUsers.size(); i++) {
            System.out.println("(" + (i + 1) + ") " + allUsers.get(i).getUsername());
        }

        System.out.println("Enter the index of the user you want to follow (or enter 0 to go back):");

        int choice = scanner.nextInt();
        scanner.nextLine();

        if (choice == 0) {
            // User chose to go back
            return;
        } else if (choice > allUsers.size() || choice < 0) {
            // Invalid choice
            System.out.println("Invalid choice. Please enter a valid index.");
            addfollow(user_log);
        } else {
            User userToFollow = allUsers.get(choice - 1);

            // Check if a follow already exists for the given users
            if (followExists(user_log, userToFollow, follows)) {
                System.out.println("You are already following " + userToFollow.getUsername());
            } else {
                // Create a new Follow instance and add it to the follows list
                Follow newFollow = new Follow(user_log, userToFollow);
                follows.add(newFollow);
                System.out.println("You are now following " + userToFollow.getUsername());
            }
        }
    }

    private static boolean followExists(User follower, User followed, List<Follow> follows) {
        for (Follow follow : follows) {
            if (follow.getFollower().equals(follower) && follow.getFollowed().equals(followed)) {
                return true;
            }
        }
        return false;
    }
}
