
package medias;

import associations.Rating;
import collections.LibraryDB;
import enums.RatingType;
import java.io.Serializable;
import java.util.List;
import java.util.Map;


public class Audio extends Media implements Serializable{
    private String creator;
    private Integer runtime;
    private String artist;
    //private List<Playlist> playlist;
    
    
    
    public Audio(String title, String filepath,String creator,Integer runtime, String artist) {
        super(title, filepath);
        this.artist = artist;
        this.runtime = runtime;
        this.creator = creator;
    }

    /**
     * @return the creator
     */
    public String getCreator() {
        return creator;
    }

    /**
     * @param creator the creator to set
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * @return the runtime
     */
    public Integer getRuntime() {
        return runtime;
    }

    /**
     * @param runtime the runtime to set
     */
    public void setRuntime(Integer runtime) {
        this.runtime = runtime;
    }

    /**
     * @return the artist
     */
    public String getArtist() {
        return artist;
    }

    /**
     * @param artist the artist to set
     */
    public void setArtist(String artist) {
        this.artist = artist;
    }
    
    /**
     *
     * @return
     */
    @Override
      public String toString() {
        int likes = countRatings(RatingType.LIKE);
        int loves = countRatings(RatingType.LOVE);
        int dislikes = countRatings(RatingType.DISLIKE);

        return String.format("Audio: %s, Creator: %s, Runtime: %d, Artist: %s, Likes: %d, Loves: %d, Dislikes: %d",
                getTitle(), creator, runtime, artist, likes, loves, dislikes);
    }

    private int countRatings(RatingType ratingType) {
        int count = 0;

        for (Rating<?> rating : LibraryDB.ratings) {
            if (rating.getRatedItem().equals(this) && rating.getRating() == ratingType) {
                count++;
            }
        }

        return count;
    }
    
}
