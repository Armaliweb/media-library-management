
package medias;

import associations.Rating;
import collections.LibraryDB;
import enums.RatingType;
import java.io.Serializable;
import java.util.Map;


public class Image extends Media implements Serializable{
    
    private String Location;
    private String Photographer;
    
    public Image(String title, String filepath, String Location, String Photographer) {
        super(title, filepath);
        this.Location = Location;
        this.Photographer = Photographer;
    }

    /**
     * @return the Location
     */
    public String getLocation() {
        return Location;
    }

    /**
     * @param Location the Location to set
     */
    public void setLocation(String Location) {
        this.Location = Location;
    }

    /**
     * @return the Photographer
     */
    public String getPhotographer() {
        return Photographer;
    }

    /**
     * @param Photographer the Photographer to set
     */
    public void setPhotographer(String Photographer) {
        this.Photographer = Photographer;
    }
    
    @Override
    public String toString() {
        int likes = countRatings(RatingType.LIKE);
        int loves = countRatings(RatingType.LOVE);
        int dislikes = countRatings(RatingType.DISLIKE);

        return String.format("Image: %s\nLocation: %s\nPhotographer: %s\nLikes: %d\nLoves: %d\nDislikes: %d",
                getTitle(), Location, Photographer, likes, loves, dislikes);
    }

    private int countRatings(RatingType ratingType) {
        int count = 0;

        
        for (Rating<?> rating : LibraryDB.ratings) {
            if (rating.getRatedItem().equals(this) && rating.getRating() == ratingType) {
                count++;
            }
        }

        return count;
    }
}
