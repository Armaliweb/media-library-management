
package medias;

import associations.Rating;
import collections.LibraryDB;
import enums.RatingType;
import java.io.Serializable;
import java.util.Map;


public class Document extends Media implements Serializable{
    private String creator;
    private String content;
    
    
    public Document(String title, String filepath,   String creator, String content) {
        super(title, filepath);
       this. creator = creator;
       this.content = content;     
    }

    /**
     * @return the creator
     */
    public String getCreator() {
        return creator;
    }

    /**
     * @param creator the creator to set
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }
     @Override
    public String toString() {
        int likes = countRatings(RatingType.LIKE);
        int loves = countRatings(RatingType.LOVE);
        int dislikes = countRatings(RatingType.DISLIKE);

        return String.format("Document: %s\nCreator: %s\nContent: %s\nLikes: %d\nLoves: %d\nDislikes: %d",
                getTitle(), creator, content, likes, loves, dislikes);
    }

    private int countRatings(RatingType ratingType) {
        int count = 0;

        for (Rating<?> rating : LibraryDB.ratings) {
            if (rating.getRatedItem().equals(this) && rating.getRating() == ratingType) {
                count++;
            }
        }

        return count;
    }
    
    
    
}
