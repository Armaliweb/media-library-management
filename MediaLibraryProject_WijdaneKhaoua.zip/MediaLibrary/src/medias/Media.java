package medias;

import java.io.Serializable;
import java.util.Map;

public class Media implements Serializable, Comparable<Media> {

    private String title;
    private String filepath;

    public Media(String title, String filepath) {
        this.title = title;
        this.filepath = filepath;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the filepath
     */
    public String getFilepath() {
        return filepath;
    }

    /**
     * @param filepath the filepath to set
     */
    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    @Override
    public int compareTo(Media o) {
        return this.title.compareTo(o.title);
    }

}
