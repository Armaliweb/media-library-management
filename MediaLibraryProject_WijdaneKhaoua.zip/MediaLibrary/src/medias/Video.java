/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medias;

import associations.Rating;
import collections.LibraryDB;
import enums.RatingType;
import java.io.Serializable;
import java.util.Map;


public class Video extends Media implements Serializable{
    private String Producer;
    private Integer Duration;
    
    public Video(String title, String filepath, String Producer, Integer Duration) {
        super(title, filepath);
        this.Duration = Duration;
        this.Producer = Producer;
    }

    /**
     * @return the Producer
     */
    public String getProducer() {
        return Producer;
    }

    /**
     * @param Producer the Producer to set
     */
    public void setProducer(String Producer) {
        this.Producer = Producer;
    }

    /**
     * @return the Duration
     */
    public Integer getDuration() {
        return Duration;
    }

    /**
     * @param Duration the Duration to set
     */
    public void setDuration(Integer Duration) {
        this.Duration = Duration;
    }
    
     @Override
    public String toString() {
        int likes = countRatings(RatingType.LIKE);
        int loves = countRatings(RatingType.LOVE);
        int dislikes = countRatings(RatingType.DISLIKE);

        return String.format("Video: %s\nProducer: %s\nDuration: %d seconds\nLikes: %d\nLoves: %d\nDislikes: %d",
                getTitle(), Producer, Duration, likes, loves, dislikes);
    }

    private int countRatings(RatingType ratingType) {
        int count = 0;

        for (Rating<?> rating : LibraryDB.ratings) {
            if (rating.getRatedItem().equals(this) && rating.getRating() == ratingType) {
                count++;
            }
        }

        return count;
    }
    
}
