
package associations;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import medialibrary.enduser.User;
import medias.Media;


public class Comment implements Serializable{
    private String content;
    private Media media;
    private User user;
   // private GregorianCalendar date;

    public Comment(String content, Media media, User user) {
        this.content = content;
        this.media = media;
        this.user = user;
       // setDate(dateString);
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @return the date
     */
   

   
    
    
    
     
    
}
