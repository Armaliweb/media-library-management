
package associations;

import enums.RatingType;
import java.io.Serializable;
import medialibrary.enduser.User;


public class Rating<T> implements Serializable {
    private User user;
    private RatingType rating;
    private T ratedItem;

    public Rating(User user, int ratingInput, T ratedItem) {
        this.user = user;
        this.rating = mapRatingInput(ratingInput);
        this.ratedItem = ratedItem;
    }

    private RatingType mapRatingInput(int ratingInput) {
        switch (ratingInput) {
            case 1:
                return RatingType.DISLIKE;
            case 2:
                return RatingType.LIKE;
            case 3:
                return RatingType.LOVE;
            default:
                throw new IllegalArgumentException("Invalid rating input: " + ratingInput);
        }
    }

    /**
     * @return the ratedItem
     */
    public T getRatedItem() {
        return ratedItem;
    }

    /**
     * @return the rating
     */
    public RatingType getRating() {
        return rating;
    }

    
}

